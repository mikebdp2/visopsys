#ifndef _NTFS_UPCASE_H_
#define _NTFS_UPCASE_H_

void init_upcase_table(ntfschar *uc, u32 uc_len);

#endif /* _NTFS_UPCASE_H_ */

