#!/bin/sh
##
##  Visopsys
##  Copyright (C) 1998-2023 J. Andrew McLaughlin
##
##  release.sh
##

# Outputs the release number
echo "0.92"
exit 0

