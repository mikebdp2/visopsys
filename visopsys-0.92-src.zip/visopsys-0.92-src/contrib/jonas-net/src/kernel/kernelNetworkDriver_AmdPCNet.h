

void kernelNetworkGetDriver_AmdPCNet(kernelNetworkInterface * nic);
